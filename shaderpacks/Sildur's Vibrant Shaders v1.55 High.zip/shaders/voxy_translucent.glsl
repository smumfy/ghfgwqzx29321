layout(location = 0) out vec4 fragData0;
layout(location = 1) out vec4 fragData1;
layout(location = 2) out vec4 fragData2;

/*
Sildur's Vibrant Shaders:
https://www.patreon.com/Sildur
https://sildurs-shaders.github.io/
https://twitter.com/SildurFX
https://www.curseforge.com/minecraft/shaders/sildurs-vibrant-shaders

Permissions:
You are not allowed to edit, copy code or share my shaderpack under a different name or claim it as yours.
*/

#define composite2
#define gbuffers_shadows
#define gbuffers_water
#define lightingColors
#include "shaders.settings"


// vertex

const vec3 ToD[7] = vec3[7](  vec3(0.58597,0.16,0.005),
								vec3(0.58597,0.31,0.05),
								vec3(0.58597,0.45,0.16),
								vec3(0.58597,0.5,0.35),
								vec3(0.58597,0.5,0.36),
								vec3(0.58597,0.5,0.37),
								vec3(0.58597,0.5,0.38));

float SunIntensity(float zenithAngleCos, float sunIntensity, float cutoffAngle, float steepness){
	return sunIntensity * max(0.0, 1.0 - exp(-((cutoffAngle - acos(zenithAngleCos))/steepness)));
}

float luma(vec3 color) {
	return dot(color,vec3(0.299, 0.587, 0.114));
}

#ifdef TAA
vec2 texelSize = vec2(1.0/viewWidth,1.0/viewHeight);
uniform int framemod8;
const vec2[8] offsets = vec2[8](vec2(1./8.,-3./8.),
								vec2(-1.,3.)/8.,
								vec2(5.0,1.)/8.,
								vec2(-3,-5.)/8.,
								vec2(-5.,5.)/8.,
								vec2(-7.,-1.)/8.,
								vec2(3,7.)/8.,
								vec2(7.,-7.)/8.);
#endif


//Moving entities IDs
//See block.properties for mapped ids
#define ENTITY_ICE 			10079.0
#define ENTITY_WATER 		10008.0


// fragment

mat2 rmatrix(float rad){
	return mat2(vec2(cos(rad), -sin(rad)), vec2(sin(rad), cos(rad)));
}

float calcWaves(vec2 coord, float iswater){
	
	if(iswater > 0.9){
	vec2 movement = abs(vec2(0.0, -frameTimeCounter * 0.31365));

	coord *= 0.262144;
	vec2 coord0 = coord * rmatrix(1.0) - movement * 4.0;
		 coord0.y *= 3.0;
	vec2 coord1 = coord * rmatrix(0.5) - movement * 1.5;
		 coord1.y *= 3.0;		 
	vec2 coord2 = coord + movement * 0.5;
		 coord2.y *= 3.0;
	
	coord0 *= waveSize;
	coord1 *= waveSize;

	float wave = 1.0 - texture2D(noisetex,coord0 * 0.005).x * 10.0;			//big waves
		  wave += texture2D(noisetex,coord1 * 0.010416).x * 7.0;			//small waves
		  wave += sqrt(texture2D(noisetex,coord2 * 0.045).x * 6.5) * 1.33;	//noise texture
		  wave *= 0.0157;
	return wave;
	} else return sqrt(texture2D(noisetex,coord * 0.5).x) * 0.035;			//translucent noise, non water

}

vec3 calcBump(vec2 coord, float iswater){
	const vec2 deltaPos = vec2(0.25, 0.0);

	float h0 = calcWaves(coord, iswater);
	float h1 = calcWaves(coord + deltaPos.xy, iswater);
	float h2 = calcWaves(coord - deltaPos.xy, iswater);
	float h3 = calcWaves(coord + deltaPos.yx, iswater);
	float h4 = calcWaves(coord - deltaPos.yx, iswater);

	float xDelta = ((h1-h0)+(h0-h2));
	float yDelta = ((h3-h0)+(h0-h4));

	return vec3(vec2(xDelta,yDelta)*0.5, 0.5); //z = 1.0-0.5
}

vec3 toScreenSpace(vec3 pos) {
	vec4 iProjDiag = vec4(vxProjInv[0].x, vxProjInv[1].y, vxProjInv[2].zw);
    vec3 p3 = pos * 2.0 - 1.0;
    vec4 viewPos = iProjDiag * p3.xyzz + vxProjInv[3];
    return viewPos.xyz / viewPos.w;
}

#ifdef WaterParallax
vec3 calcParallax(vec3 pos, vec2 view, float iswater){
	float getwave = calcWaves(pos.xz - pos.y, iswater);

	pos.xz += (getwave * view) * waterheight;
	
	return pos;
}
#endif

vec4 encode (vec3 n, float dif, float lmap, float mat){
    float p = sqrt(n.z*8+8);
	
	float vis = lmap;
	if (mat > 0.9) vis = vis * 0.25;
	if (mat > 0.4 && mat < 0.6) vis = vis*0.25+0.25;
	if (mat < 0.1) vis = vis*0.25+0.5;
		
    return vec4(n.xy/p + 0.5,vis,1.0);
}


void voxy_emitFragment(VoxyFragmentParameters parameters) {

	// vertex
	vec3 normal = vec3(0.0);

	switch (uint(parameters.face) >> 1u) {
		case 0u:
		normal.xyz = vxModelView[1].xyz;
		break;
		case 1u:
		normal.xyz  = vxModelView[2].xyz;
		break;
		case 2u:
		normal.xyz  = vxModelView[0].xyz;
		break;
	}
	if ((parameters.face & 1) == 0) {
		normal.xyz  = -normal.xyz ;
	}


	float material = 0.0;
	float removeWater = 1.0; //disable lightmap on water, make light go through instead
	if(parameters.customId == ENTITY_WATER) {
		material = 1.0;
		removeWater = 0.0;
	#ifdef Waving_Water
		/*float fy = fract(worldpos.y + 0.001);
		float wave = 0.05 * sin(2 * PI * (frameTimeCounter*0.8 + worldpos.x /  2.5 + worldpos.z / 5.0))
				   + 0.05 * sin(2 * PI * (frameTimeCounter*0.6 + worldpos.x / 6.0 + worldpos.z /  12.0));
		position.y += clamp(wave, -fy, 1.0-fy)*waves_amplitude;*/
	#endif
	}
	if(parameters.customId == ENTITY_ICE) material = 0.5;

	//ToD
	float hour = max(mod(worldTime/1000.0+2.0,24.0)-2.0,0.0);  //-0.1
	float cmpH = max(-abs(floor(hour)-6.0)+6.0,0.0); //12
	float cmpH1 = max(-abs(floor(hour)-5.0)+6.0,0.0); //1
	
	#ifdef MC_GL_VENDOR_ATI
		vec3 sunlight = vec3(1.0); //Time of day calculation breaks water on amd drivers 18.8.1, last working driver was 18.6.1, causes heavy flickering. TESTED ON RX460
	#else
		vec3 sunlight = mix(ToD[int(cmpH)], ToD[int(cmpH1)], fract(hour));
	#endif
	sunlight.rgb += vec3(r_multiplier,g_multiplier,b_multiplier); //allows lighting colors to be tweaked.
	sunlight.rgb *= light_brightness; //brightness needs to be adjusted if we tweak lighting colors.
	//---

	//lightmap
	float torch_lightmap = 16.0-min(15.0,(parameters.lightMap.x-0.5/16.0)*16.0*16.0/15.0);
	float fallof1 = clamp(1.0 - pow(torch_lightmap/16.0,4.0),0.0,1.0);
	torch_lightmap = fallof1*fallof1/(torch_lightmap*torch_lightmap+1.0);
	torch_lightmap *= removeWater;
	vec3 emissiveLightC = vec3(emissive_R,emissive_G,emissive_B)*torch_lightmap*0.2;
	//---

	//light bounce
	vec3 sunVec = normalize(sunPosition);
	vec3 upVec = normalize(upPosition);

	vec2 visibility = vec2(dot(sunVec,upVec),dot(-sunVec,upVec));
	
	float cutoffAngle = 1.608;
	float steepness = 1.5;
	float cosSunUpAngle = dot(sunVec, upVec) * 0.95 + 0.05; //Has a lower offset making it scatter when sun is below the horizon.
	float sunE = SunIntensity(cosSunUpAngle, 1000.0, cutoffAngle, steepness);  // Get sun intensity based on how high in the sky it is

	float NdotL = dot(normal,sunVec);
	float NdotU = dot(normal,upVec);

	vec2 trCalc = min(abs(worldTime-vec2(23000.0,12700.0)),750.0); //adjust to make day-night switch smoother
	float tr = max(min(trCalc.x,trCalc.y)/375.0-1.0,0.0);
	visibility = pow(clamp(visibility+0.15,0.0,0.3)/0.3,vec2(4.4));
	sunlight = sunlight/luma(sunlight)*sunE*0.0075*0.075*3.*visibility.x;
	
	float skyL = max(parameters.lightMap.y-2./16.0,0.0)*1.14285714286;	
	float SkyL2 = skyL*skyL;
	float skyc2 = mix(1.0,SkyL2,skyL);

	vec4 bounced = vec4(NdotL,NdotL,NdotL,NdotU) * vec4(-0.14*skyL*skyL,0.33,0.7,0.1) + vec4(0.6,0.66,0.7,0.25);
		 bounced *= vec4(skyc2,skyc2,visibility.x-tr*visibility.x,0.8);
	
	vec3 ambientC = mix(vec3(0.3, 0.5, 1.1),vec3(0.08,0.1,0.1),rainStrength)*length(sunlight)*bounced.w;
		 ambientC += 0.25*sunlight*(bounced.x + bounced.z)*(0.03+tr*0.17)/0.4*(1.0-rainStrength*0.98)  + length(sunlight)*0.2*(1.0-rainStrength*0.9);
		 ambientC += sunlight*(NdotL*0.5+0.45)*visibility.x*(1.0-tr)*(1.0-tr)*4.*(1.0-rainStrength*0.98);

	//lighting during night time
	const vec3 moonlight = vec3(0.0024, 0.00432, 0.0078);	
	vec3 moon_ambient = (moonlight*2.0 + moonlight*bounced.y)*(4.0-rainStrength*0.95)*0.2;
	vec3 moonC = (moon_ambient*visibility.y)*SkyL2*(0.03*0.65+tr*0.17*0.65);

	float wminlight = (nightVision > 0.01)? 0.075: 0.00008;
	vec3 getAmbientNdotLColor = ambientC*SkyL2*0.3 + moonC + emissiveLightC + wminlight;
		
	//sunlight = mix(sunlight,moonlight*(1.0-rainStrength*0.9),visibility.y)*tr;
	sunlight = mix(sunlight,moonlight*(1.0-rainStrength*0.9),visibility.y);	//remove time check to improve day-night transition

	vec3 getSunlight = sunlight;
	//---


	// fragment 

	vec4 albedo = parameters.sampledColour * parameters.tinting;
		 albedo.rgb = pow(albedo.rgb,vec3(2.2));

    vec3 viewPos = toScreenSpace(vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z));
   
	mat3 tbnMatrix = mat3(vxModelView[0].x, vxModelView[2].x, normal.x,
						  vxModelView[0].y, vxModelView[2].y, normal.y,
						  vxModelView[0].z, vxModelView[2].z, normal.z);

	vec3 worldPos = mat3(vxModelViewInv) * viewPos + vxModelViewInv[3].xyz;

    vec3 waterpos = worldPos + cameraPosition;
	#ifdef WaterParallax
		waterpos = calcParallax(waterpos, worldPos.xz / length(worldPos.xz) * 8.25, material);
	#endif
	normal = clamp(normalize(calcBump(waterpos.xz - waterpos.y, material) * tbnMatrix), vec3(-1.0), vec3(1.0)); 

	//float iswater = clamp(material*2.0-1.0,0.0,1.0);

	float texvis = wtexblend;

	#ifndef watertex
		texvis = 0.11;
		if(material > 0.9)albedo.rgb = vec3(waterCR,waterCG,waterCB);
	#endif

	float diffuse = clamp(dot(normal, normalize(shadowLightPosition))*1.02-0.02,0.0,1.0) * removeWater; //don't diffuse water
		  diffuse *= (1.0 - rainStrength);

	vec3 finalsunlight = getSunlight.rgb*diffuse*(1.0-rainStrength*0.99)*0.85;	  

	vec3 fColor = albedo.rgb*(finalsunlight+getAmbientNdotLColor);	
	float alpha = mix(albedo.a, texvis, material);
	if(material > 0.9)alpha *= waterA;

	//fix hand rendering
    if(texture2D(depthtex2, gl_FragCoord.xy / vec2(viewWidth, viewHeight)).x > texture2D(depthtex1, gl_FragCoord.xy / vec2(viewWidth, viewHeight)).x) discard;

    fragData0 = vec4(fColor, alpha);
    fragData1 = encode(normal, diffuse, parameters.lightMap.y, material);
	fragData2 = vec4(normalize(albedo.rgb+0.00001), alpha);
}