#version 120
/* DRAWBUFFERS:3 */

#define gbuffers_skytextured
#include "/shaders.settings"

varying vec4 color;
varying vec2 texcoord;
uniform sampler2D texture;

void main() {

vec4 albedo = texture2D(texture, texcoord.xy)*color*0.85;
#ifdef IRIS_END_FIX
    #if defined(IS_IRIS) && (MC_VERSION >= 12105)
        albedo.rgb *= 0.15;
    #endif
#endif

gl_FragData[0] = albedo;
}